CREATE TABLE IF NOT EXISTS restaurants(id INT PRIMARY KEY, name VARCHAR(80), cuisine VARCHAR(40));
CREATE TABLE IF NOT EXISTS menu_items(id INT AUTO_INCREMENT PRIMARY KEY, rid INT, name VARCHAR(80), price DECIMAL(8,2), veg BOOLEAN);
CREATE TABLE IF NOT EXISTS orders(id INT AUTO_INCREMENT PRIMARY KEY, customer VARCHAR(60), rid INT, total DECIMAL(8,2),
  status VARCHAR(20) DEFAULT 'PLACED', partner VARCHAR(60), created TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items(order_id INT, item_id INT, qty INT);
MERGE INTO restaurants KEY(id) VALUES (1,'Spice Hub','Indian'),(2,'Pizza Corner','Italian'),(3,'Green Bowl','Healthy');
MERGE INTO menu_items KEY(id) VALUES (1,1,'Paneer Butter Masala',180,TRUE),(2,1,'Chicken Biryani',220,FALSE),(3,1,'Garlic Naan',40,TRUE),
 (4,2,'Margherita Pizza',250,TRUE),(5,2,'Pepperoni Pizza',320,FALSE),(6,2,'Garlic Bread',90,TRUE),
 (7,3,'Quinoa Salad',150,TRUE),(8,3,'Grilled Chicken Bowl',230,FALSE),(9,3,'Fruit Smoothie',110,TRUE);
