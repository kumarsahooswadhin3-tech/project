
const STEPS = [
    'PLACED',
    'PREPARING',
    'READY',
    'PICKED_UP',
    'DELIVERED'
];

const restaurants = [
    {id: 1, name: 'Spice Hub', cuisine: 'Indian'},
    {id: 2, name: 'Pizza Point', cuisine: 'Italian'},
    {id: 3, name: 'Green Bowl', cuisine: 'Healthy'}
];

let menus = {
    1: [
        {id: 101, name: 'Veg Biryani', price: 140, veg: true},
        {id: 102, name: 'Paneer Masala', price: 180, veg: true},
        {id: 103, name: 'Chicken Biryani', price: 190, veg: false}
    ],

    2: [
        {id: 201, name: 'Margherita Pizza', price: 160, veg: true},
        {id: 202, name: 'Farmhouse Pizza', price: 220, veg: true},
        {id: 203, name: 'Chicken Pizza', price: 250, veg: false}
    ],

    3: [
        {id: 301, name: 'Fruit Salad', price: 90, veg: true},
        {id: 302, name: 'Veg Sandwich', price: 110, veg: true},
        {id: 303, name: 'Protein Bowl', price: 170, veg: true}
    ]
};

let cart = {};
let orders = [];
let nextOrderId = 1001;
let selectedRestaurant = 1;

const $ = id => document.getElementById(id);

// Initialize application
function init() {

    const options = restaurants.map(r =>
        `<option value="${r.id}">
            ${r.name} (${r.cuisine})
        </option>`
    ).join('');

    $('rest').innerHTML = options;
    $('drest').innerHTML = options;

    loadMenu();
    reco();
}

// Navigation
function show(id) {

    ['customer', 'restaurant', 'delivery', 'track']
    .forEach(s => {
        $(s).hidden = s !== id;
    });

    if (id === 'restaurant') loadDash();
    if (id === 'delivery') loadDelivery();
}

// Load food menu
function loadMenu() {

    selectedRestaurant = Number($('rest').value);

    cart = {};
    renderCart();

    const items = menus[selectedRestaurant];

    $('menu').innerHTML = items.map(item => `
        <div class="card">

            <div>
                <strong>
                    ${item.veg ? '🟢' : '🔴'}
                    ${item.name}
                </strong>

                <p>₹${item.price}</p>
            </div>

            <button onclick="addToCart(${item.id})">
                Add to Cart
            </button>

        </div>
    `).join('');
}

// Add food to cart
function addToCart(id) {

    const item = Object.values(menus)
        .flat()
        .find(x => x.id === id);

    if (!item) return;

    cart[id] = (cart[id] || 0) + 1;

    renderCart();
}

// Increase and decrease quantity
function changeQuantity(id, change) {

    cart[id] = (cart[id] || 0) + change;

    if (cart[id] <= 0) {
        delete cart[id];
    }

    renderCart();
}

// Display cart and total
function renderCart() {

    const ids = Object.keys(cart);

    if (ids.length === 0) {

        $('cart').innerHTML = 'Your cart is empty.';
        $('total').textContent = 0;

        return;
    }

    let total = 0;

    $('cart').innerHTML = ids.map(id => {

        const item = Object.values(menus)
            .flat()
            .find(x => x.id === Number(id));

        const quantity = cart[id];
        const subtotal = item.price * quantity;

        total += subtotal;

        return `
            <div class="cart-row">

                <span>
                    ${item.name} × ${quantity}
                    = ₹${subtotal}
                </span>

                <span>
                    <button onclick="changeQuantity(${id}, -1)">−</button>

                    <button onclick="changeQuantity(${id}, 1)">+</button>
                </span>

            </div>
        `;

    }).join('');

    $('total').textContent = total;
}

// Place order
function placeOrder() {

    if (Object.keys(cart).length === 0) {

        alert('Please select food first!');
        return;
    }

    const restaurant = restaurants.find(
        r => r.id === selectedRestaurant
    );

    const items = Object.keys(cart).map(id => {

        const item = Object.values(menus)
            .flat()
            .find(x => x.id === Number(id));

        return {
            ...item,
            quantity: cart[id]
        };
    });

    const total = items.reduce(
        (sum, item) =>
            sum + item.price * item.quantity, 0
    );

    const order = {

        id: nextOrderId++,

        customer: $('cname').value || 'Customer',

        restaurantId: selectedRestaurant,

        restaurant: restaurant.name,

        items: items,

        total: total,

        status: 'PLACED',

        partner: ''
    };

    orders.push(order);

    $('tid').value = order.id;

    cart = {};

    renderCart();

    alert(
        `Order #${order.id} placed successfully! Total ₹${total}`
    );

    loadDash();
}

// Food recommendations (demo)
function reco() {

    const items = menus[selectedRestaurant] || [];

    $('reco').innerHTML = items.slice(0, 2)
        .map(i => `
            <div class="card">
                ${i.name} — ₹${i.price}
            </div>
        `).join('');
}

// Food assistant (demo logic)
function ask() {

    const q = $('q').value.toLowerCase();

    let items = Object.values(menus).flat();

    if (q.includes('veg')) {

        items = items.filter(i => i.veg);

    } else if (q.includes('cheap')) {

        items = items.filter(i => i.price <= 150);

    } else if (q.includes('pizza')) {

        items = items.filter(i =>
            i.name.toLowerCase().includes('pizza')
        );

    } else {

        items = items.slice(0, 3);
    }

    $('chat').innerHTML = items.map(i => `
        <div class="card">
            ${i.name} — ₹${i.price}
        </div>
    `).join('') || 'No matching food found.';
}

// Restaurant dashboard
function loadDash() {

    const rid = Number($('drest').value);

    const list = orders.filter(
        o => o.restaurantId === rid
    );

    $('dorders').innerHTML = list.map(o => {

        const next = {
            PLACED: 'PREPARING',
            PREPARING: 'READY'
        }[o.status];

        return `
            <div class="card">

                <span>
                    #${o.id} ${o.customer}
                    ₹${o.total}
                    <strong>${o.status}</strong>
                </span>

                ${next ? `
                    <button onclick="setStatus(${o.id}, '${next}')">
                        Mark ${next}
                    </button>
                ` : ''}

            </div>
        `;

    }).join('') || 'No orders yet.';
}

// Update order status
function setStatus(id, status, partner = '') {

    const order = orders.find(o => o.id === id);

    if (!order) return;

    order.status = status;

    if (partner) {
        order.partner = partner;
    }

    loadDash();
    loadDelivery();
    track();
}

// Add new food item
function addItem() {

    const name = $('mname').value.trim();
    const price = Number($('mprice').value);

    if (!name || price <= 0) {

        alert('Enter valid food name and price.');
        return;
    }

    const rid = Number($('drest').value);

    menus[rid].push({

        id: Date.now(),

        name: name,

        price: price,

        veg: $('mveg').checked
    });

    $('mname').value = '';
    $('mprice').value = '';
    $('mveg').checked = false;

    alert('Food item added successfully!');

    if (rid === selectedRestaurant) {
        loadMenu();
    }
}

// Delivery dashboard
function loadDelivery() {

    const ready = orders.filter(
        o => o.status === 'READY'
    );

    const picked = orders.filter(
        o => o.status === 'PICKED_UP'
    );

    $('dlist').innerHTML =

        ready.map(o => `
            <div class="card">

                Order #${o.id} — ${o.customer}

                <button onclick="setStatus(
                    ${o.id},
                    'PICKED_UP',
                    $('pname').value
                )">
                    Pick Up
                </button>

            </div>
        `).join('') +

        picked.map(o => `
            <div class="card">

                Order #${o.id} — ${o.customer}

                <button onclick="setStatus(${o.id}, 'DELIVERED')">
                    Delivered
                </button>

            </div>
        `).join('');

    if (!ready.length && !picked.length) {
        $('dlist').innerHTML = 'No deliveries available.';
    }
}

// Track order
function track() {

    const id = Number($('tid').value);

    const order = orders.find(o => o.id === id);

    if (!order) {

        $('tinfo').innerHTML = 'Order not found.';
        return;
    }

    const index = STEPS.indexOf(order.status);

    $('tinfo').innerHTML = `

        <p>
            ${order.restaurant} —
            Order #${order.id}
        </p>

        <p>Total: ₹${order.total}</p>

        <div class="steps">

            ${STEPS.map((s, i) => `

                <div class="step ${i <= index ? 'done' : ''}">
                    ${s}
                </div>

            `).join('')}

        </div>

        <p>Current Status: <strong>${order.status}</strong></p>

        <p>
            ${order.status === 'DELIVERED'
                ? 'Delivered successfully ✅'
                : order.status === 'PICKED_UP'
                ? 'Rider: ' + order.partner
                : 'Your order is being processed.'}
        </p>
    `;
}

// Start application
init();
