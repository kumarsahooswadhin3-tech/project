import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class Main {
    static Connection db;

    public static void main(String[] args) throws Exception {
        db = DriverManager.getConnection("jdbc:h2:./fooddb;INIT=RUNSCRIPT FROM 'schema.sql'");
        HttpServer s = HttpServer.create(new InetSocketAddress(8080), 0);
        s.createContext("/", Main::handle);
        s.start();
        System.out.println("Running at http://localhost:8080");
    }

    // ---------- HTTP ----------
    static void handle(HttpExchange e) throws IOException {
        String path = e.getRequestURI().getPath(), type = "application/json", out;
        try {
            if (path.startsWith("/api/")) out = api(path, params(e.getRequestURI().getRawQuery()));
            else {
                if (path.equals("/")) path = "/index.html";
                out = Files.readString(Paths.get("web" + path));
                type = path.endsWith(".css") ? "text/css" : path.endsWith(".js") ? "text/javascript" : "text/html";
            }
        } catch (Exception ex) {
            out = "{\"error\":\"" + String.valueOf(ex.getMessage()).replace("\"", "'") + "\"}";
        }
        byte[] b = out.getBytes("UTF-8");
        e.getResponseHeaders().set("Content-Type", type + "; charset=UTF-8");
        e.sendResponseHeaders(200, b.length);
        e.getResponseBody().write(b);
        e.close();
    }

    static Map<String, String> params(String q) throws Exception {
        Map<String, String> m = new HashMap<>();
        if (q != null) for (String kv : q.split("&")) {
            String[] p = kv.split("=", 2);
            m.put(p[0], p.length > 1 ? URLDecoder.decode(p[1], "UTF-8") : "");
        }
        return m;
    }

    // ---------- API ----------
    static String api(String path, Map<String, String> p) throws Exception {
        switch (path) {
            case "/api/restaurants": return json("SELECT * FROM restaurants");
            case "/api/menu": return json("SELECT * FROM menu_items WHERE rid=?", Integer.parseInt(p.get("rid")));
            case "/api/menu/add":   // restaurant dashboard
                exec("INSERT INTO menu_items(rid,name,price,veg) VALUES(?,?,?,?)", Integer.parseInt(p.get("rid")),
                     p.get("name"), Double.parseDouble(p.get("price")), "true".equals(p.get("veg")));
                return "{\"ok\":true}";
            case "/api/order": return placeOrder(p);
            case "/api/orders":     // filter by rid / customer / status
                if (p.containsKey("rid"))      return json("SELECT * FROM orders WHERE rid=? ORDER BY id DESC", Integer.parseInt(p.get("rid")));
                if (p.containsKey("customer")) return json("SELECT * FROM orders WHERE customer=? ORDER BY id DESC", p.get("customer"));
                return json("SELECT * FROM orders WHERE status=? ORDER BY id", p.get("status"));
            case "/api/status":     // restaurant / delivery partner updates
                exec("UPDATE orders SET status=?, partner=COALESCE(?,partner) WHERE id=?", p.get("status"), p.get("partner"), Integer.parseInt(p.get("id")));
                return "{\"ok\":true}";
            case "/api/track": return json("SELECT o.id,o.status,o.partner,o.total,r.name restaurant FROM orders o JOIN restaurants r ON r.id=o.rid WHERE o.id=?", Integer.parseInt(p.get("id")));
            case "/api/ai/recommend": return recommend(p.get("customer"));
            case "/api/ai/eta": return eta(Integer.parseInt(p.get("id")));
            case "/api/ai/chat": return chat(p.getOrDefault("q", "").toLowerCase());
        }
        return "{\"error\":\"unknown endpoint\"}";
    }

    static String placeOrder(Map<String, String> p) throws Exception {
        double total = 0;
        String[] items = p.get("items").split(",");               // format: itemId:qty,itemId:qty
        for (String it : items) {
            String[] x = it.split(":");
            ResultSet r = query("SELECT price FROM menu_items WHERE id=?", Integer.parseInt(x[0]));
            r.next();
            total += r.getDouble(1) * Integer.parseInt(x[1]);
        }
        PreparedStatement ps = db.prepareStatement("INSERT INTO orders(customer,rid,total) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
        ps.setString(1, p.get("customer")); ps.setInt(2, Integer.parseInt(p.get("rid"))); ps.setDouble(3, total);
        ps.executeUpdate();
        ResultSet k = ps.getGeneratedKeys(); k.next();
        int id = k.getInt(1);
        for (String it : items) {
            String[] x = it.split(":");
            exec("INSERT INTO order_items VALUES(?,?,?)", id, Integer.parseInt(x[0]), Integer.parseInt(x[1]));
        }
        return "{\"orderId\":" + id + ",\"total\":" + total + "}";
    }

    // ---------- "AI" (simple, explainable) ----------
    // 1. Recommendation: customers who ordered what you ordered also ordered...
    static String recommend(String customer) throws Exception {
        String mine = "SELECT oi.item_id FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.customer=?";
        String sql = "SELECT m.id,m.name,m.price,COUNT(*) score FROM order_items oi JOIN menu_items m ON m.id=oi.item_id "
                   + "WHERE oi.order_id IN (SELECT order_id FROM order_items WHERE item_id IN (" + mine + ")) "
                   + "AND m.id NOT IN (" + mine + ") GROUP BY m.id,m.name,m.price ORDER BY score DESC LIMIT 3";
        String r = json(sql, customer, customer);
        if (r.equals("[]"))  // new customer -> most popular items
            r = json("SELECT m.id,m.name,m.price,COUNT(*) score FROM order_items oi JOIN menu_items m ON m.id=oi.item_id GROUP BY m.id,m.name,m.price ORDER BY score DESC LIMIT 3");
        return r;
    }

    // 2. ETA prediction: prep time grows with items and kitchen load; then delivery time
    static String eta(int id) throws Exception {
        ResultSet r = query("SELECT status,rid FROM orders WHERE id=?", id);
        if (!r.next()) return "{\"error\":\"no such order\"}";
        String st = r.getString(1); int rid = r.getInt(2);
        ResultSet n = query("SELECT COALESCE(SUM(qty),0) FROM order_items WHERE order_id=?", id); n.next();
        ResultSet l = query("SELECT COUNT(*) FROM orders WHERE rid=? AND status IN ('PLACED','PREPARING')", rid); l.next();
        int prep = 10 + 2 * n.getInt(1) + 3 * l.getInt(1), ride = 15, mins;
        switch (st) {
            case "PLACED": mins = prep + ride; break;
            case "PREPARING": mins = prep / 2 + ride; break;
            case "READY": mins = ride + 3; break;
            case "PICKED_UP": mins = ride / 2; break;
            default: mins = 0;
        }
        return "{\"minutes\":" + mins + "}";
    }

    // 3. Chat assistant: keyword intent matching over the menu
    static String chat(String q) throws Exception {
        if (q.contains("veg") && !q.contains("non"))
            return reply("Vegetarian picks:", json("SELECT name,price FROM menu_items WHERE veg=TRUE LIMIT 5"));
        if (q.contains("non") || q.contains("chicken") || q.contains("meat"))
            return reply("Non-veg picks:", json("SELECT name,price FROM menu_items WHERE veg=FALSE LIMIT 5"));
        if (q.contains("cheap") || q.contains("budget"))
            return reply("Best on a budget:", json("SELECT name,price FROM menu_items ORDER BY price LIMIT 3"));
        ResultSet r = query("SELECT COUNT(*) FROM menu_items WHERE LOWER(name) LIKE ?", "%" + q + "%"); r.next();
        if (q.length() > 2 && r.getInt(1) > 0)
            return reply("Found these:", json("SELECT name,price FROM menu_items WHERE LOWER(name) LIKE ?", "%" + q + "%"));
        return "{\"text\":\"Try: 'veg food', 'something cheap', 'chicken', or a dish name like 'pizza'.\"}";
    }
    static String reply(String text, String items) {
        return "{\"text\":\"" + text + "\",\"items\":" + items + "}";
    }

    // ---------- JDBC helpers ----------
    static ResultSet query(String sql, Object... a) throws SQLException {
        PreparedStatement ps = db.prepareStatement(sql);
        for (int i = 0; i < a.length; i++) ps.setObject(i + 1, a[i]);
        return ps.executeQuery();
    }
    static void exec(String sql, Object... a) throws SQLException {
        PreparedStatement ps = db.prepareStatement(sql);
        for (int i = 0; i < a.length; i++) ps.setObject(i + 1, a[i]);
        ps.executeUpdate();
    }
    static String json(String sql, Object... a) throws SQLException {
        ResultSet rs = query(sql, a);
        ResultSetMetaData m = rs.getMetaData();
        StringBuilder sb = new StringBuilder("[");
        while (rs.next()) {
            if (sb.length() > 1) sb.append(',');
            sb.append('{');
            for (int i = 1; i <= m.getColumnCount(); i++) {
                if (i > 1) sb.append(',');
                sb.append('"').append(m.getColumnLabel(i).toLowerCase()).append("\":\"")
                  .append(String.valueOf(rs.getObject(i)).replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
            }
            sb.append('}');
        }
        return sb.append(']').toString();
    }
}
